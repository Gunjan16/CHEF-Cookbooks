#
# Cookbook Name:: join_domain
# Recipe:: default
#
# Copyright (c) 2016 The Authors, All Rights Reserved.


include_recipe 'join_domain::join_domain'