#
# Cookbook Name:: join_domain
# Recipe:: join_domain
#
# Copyright (c) 2016 The Authors, All Rights Reserved.
#log = File.open('c:\\temp\\joindomain.log', 'a')
#secret = data_bag_item("#{node['join_domain']['databag_name']}", 'join_domain', IO.read('C:/chef/validator.pem'))

powershell_script 'add_to_windows_domain' do
  code <<-EOH
  $adminname = "test.com\\Gunjan"
  $SecPassword = "Qwerty123456" | ConvertTo-SecureString -asPlainText -Force
  $credential = New-Object System.Management.Automation.PSCredential($adminname,$SecPassword)
  $hostname = "#{node['join_domain']['hostname']}"
  Add-Computer -Computername $hostname -Credential $credential -DomainName #{node['join_domain']['domain']} -Force
  EOH
  not_if 'Test-ComputerSecureChannel'
end

#log.write("llama_env at recipe converge: #{node['llama_env']}")