#log = File.open('c:\\temp\\joindomain.log', 'a')
#log.write "llama_env at very beginning of run: #{node['llama_env']}"
default['join_domain']['hostname'] = node['hostname']
default['join_domain']['domain']   = "test.com" 
# env1 = node['llama_env']
#if node['llama_env'].casecmp('qa').zero? || node['llama_env'].casecmp('dev').zero?
 # log.write "matches first condition"
  #default['join_domain']['domain']       = 'llamadev.local'
  #default['join_domain']['databag_name'] = 'cve_bag'
#elsif node['llama_env'].casecmp('staging').zero? || node['llama_env'].casecmp('prod').zero?
#  log.write "matches second condition"
 # default['join_domain']['domain']       = 'scg.guru'
  #default['join_domain']['databag_name'] = 'scgguruprod_bag'
#elsif (node['llama_env'].include? 'stage') || (node['llama_env'].include? 'prod')
 # log.write "matches third condition"
 # default['join_domain']['domain']       = 'scg.guru'
 # default['join_domain']['databag_name'] = 'scgguruprod_bag'
#else
  # For now we assume that anything not staging or prod is going to llamadev
 # default['join_domain']['domain']       = 'llamadev.local'
 # default['join_domain']['databag_name'] = 'cve_bag'
#end

#if node['llama_env'] == 'prod003'
#  log.write "matches final outlier condition"
#  default['join_domain']['domain']       = 'scg.guru'
#  default['join_domain']['databag_name'] = 'scgguruprod_bag'
#end


#log.write("llama_env at the end of attributes: #{node['llama_env']}")