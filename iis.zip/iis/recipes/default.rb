#
# Cookbook:: iis
# Recipe:: default
#
# Copyright:: 2021, The Authors, All Rights Reserved.

powershell_script 'Install IIS' do
	action :run
	code 'add-windowsfeature web-server'
end

service 'w3svc' do
	action [:enable, :start]
end

template 'c:\inetpub\wwwroot\Default.htm' do
	source 'Default.htm.erb'
	rights :read, 'Everyone'
end