Sa_password add krna hai server.rb mde in attributes

Product key

Update_Enabled= false

['Administrator'] = Gunjan //PC ka naam
